package org.design;

import com.google.common.util.concurrent.Uninterruptibles;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.concurrent.TimeUnit;

public class SearchComponent extends AbstractComponent{

    //TODO: replace FindBy
    @FindBy(name="q")
    private WebElement searchBox;

    public SearchComponent(final WebDriver driver){
        super(driver);
    }

    public void enter(String text){
        this.searchBox.clear();
        // Simulates typing one char at a time, as google makes a backend call for each character entry
        for (char ch : text.toCharArray()){
            Uninterruptibles.sleepUninterruptibly(50, TimeUnit.MILLISECONDS);
            this.searchBox.sendKeys(String.valueOf(ch));
        }
    }

    @Override
    public boolean isDisplayed() {
        return this.wait.until((driver) -> this.searchBox.isDisplayed());
    }
}
