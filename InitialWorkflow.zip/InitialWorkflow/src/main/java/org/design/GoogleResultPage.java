package org.design;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class GoogleResultPage {

    private WebDriver driver;

    private NavigationBarComponent navigationBarComponent;
    private ResultsStatisticsComponent resultsStatisticsComponent;
    private SearchComponent searchComponent;
    private SearchSuggestionComponent searchSuggestionComponent;

    public GoogleResultPage(final WebDriver driver){
        this.driver = driver;
        // Note use of composition here as opposed to inheritance
        navigationBarComponent = PageFactory.initElements(driver, NavigationBarComponent.class);
        resultsStatisticsComponent = PageFactory.initElements(driver, ResultsStatisticsComponent.class);
        searchComponent = PageFactory.initElements(driver, SearchComponent.class);
        searchSuggestionComponent = PageFactory.initElements(driver, SearchSuggestionComponent.class);
    }

    public NavigationBarComponent getNavigationBarComponent() {
        return navigationBarComponent;
    }

    public ResultsStatisticsComponent getResultsStatisticsComponent() {
        return resultsStatisticsComponent;
    }

    public SearchComponent getSearchComponent() {
        return searchComponent;
    }

    public SearchSuggestionComponent getSearchSuggestionComponent() {
        return searchSuggestionComponent;
    }
}
