package org.design;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * This is a Page Object and has no functionality of it's own.
 * It is composed of component objects that represent parts of the website under test.
 */
public class GoogleMainPage {

    private WebDriver driver;

    private SearchComponent searchComponent;
    private SearchSuggestionComponent searchSuggestionComponent;

    public GoogleMainPage(final WebDriver driver){
        this.driver = driver;
        // Note use of composition here as opposed to inheritance
        this.searchComponent = PageFactory.initElements(driver, SearchComponent.class);
        this.searchSuggestionComponent = PageFactory.initElements(driver, SearchSuggestionComponent.class);
    }

    public void goTo(){
        this.driver.navigate().to("http://www.google.com");
    }

    public SearchComponent getSearchComponent() {
        return searchComponent;
    }

    public SearchSuggestionComponent getSearchSuggestionComponent() {
        return searchSuggestionComponent;
    }
}
