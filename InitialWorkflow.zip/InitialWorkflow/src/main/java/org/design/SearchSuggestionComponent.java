package org.design;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class SearchSuggestionComponent extends AbstractComponent{

    @FindBy(css="li.sbct")
    private List<WebElement> suggestions;

    public SearchSuggestionComponent(final WebDriver driver){
        super(driver);
    }

    /**
     *
     * @param index is 1 based for clients
     */
    public void clickSuggestionByIndex(int index){
        this.suggestions.get(index-1).click();
    }

    @Override
    public boolean isDisplayed() {
        /* Using a Lambda for flexible approach here instead of ExpectedConditions class */
        return this.wait.until((driver) -> this.suggestions.size() > 5);
    }
}
