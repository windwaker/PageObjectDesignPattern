package org.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class GooglePageEnglish extends GooglePage{

    private WebDriver driver;
    private WebDriverWait wait;

    @FindBy(name="q")
    private WebElement searchBox;

    @FindBy(name="btnk")
    private WebElement searchButton;

    @FindBy(css="div.rc")
    private List<WebElement> results;

    public GooglePageEnglish(final WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 15);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void launchSite() {
        this.driver.navigate().to("https://www.google.com");
    }

    @Override
    public void search(String keyword) {
        this.searchBox.clear();
        this.searchBox.sendKeys(keyword);
        this.searchButton.click();
    }

    @Override
    public int getResultCount() {
        this.wait.until((driver) -> this.results.size() > 1);
        return this.results.size();
    }

}
