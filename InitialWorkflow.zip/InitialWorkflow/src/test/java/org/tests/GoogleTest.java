package org.tests;

import com.tngtech.java.junit.dataprovider.DataProvider;
import com.tngtech.java.junit.dataprovider.DataProviderRunner;
import com.tngtech.java.junit.dataprovider.UseDataProvider;
import org.BaseTest;
import org.design.GoogleMainPage;
import org.design.GoogleResultPage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@RunWith(DataProviderRunner.class)
public class GoogleTest extends BaseTest {

    private GoogleResultPage googleResultPage;
    private GoogleMainPage googleMainPage;

    @Before
    public void setupPages(){
        /* instance of driver is coming frm the BaseTest class */
        this.googleResultPage = new GoogleResultPage(driver);
        this.googleMainPage = new GoogleMainPage(driver);
    }

    @Test
    @UseDataProvider("testData")
    public void test1(String keyword, int index){

        this.googleMainPage.goTo();

        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                By.cssSelector("#cnsw > iframe")));
        driver.findElement(By.cssSelector("#introAgreeButton")).click();
        driver.switchTo().defaultContent();

        Assert.assertTrue(this.googleMainPage.getSearchComponent().isDisplayed());

        googleMainPage.getSearchComponent().enter(keyword);
        Assert.assertTrue(this.googleMainPage.getSearchSuggestionComponent().isDisplayed());

        googleMainPage.getSearchSuggestionComponent().clickSuggestionByIndex(index);
        Assert.assertTrue(googleResultPage.getNavigationBarComponent().isDisplayed());

        googleResultPage.getSearchComponent().enter(keyword);
        Assert.assertTrue(googleResultPage.getSearchSuggestionComponent().isDisplayed());

        googleResultPage.getSearchSuggestionComponent().clickSuggestionByIndex(index);

        googleResultPage.getNavigationBarComponent().goToNews();

        System.out.println(googleResultPage.getResultsStatisticsComponent().getStat());

    }

    @DataProvider
    public static Object[][] testData() {
        return new Object[][]{
                {"test", 2},
                {"blah", 3},
                {"ewood", 4}
        };
    }

}
