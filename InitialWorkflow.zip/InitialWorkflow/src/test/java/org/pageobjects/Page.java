package org.pageobjects;

import org.openqa.selenium.WebDriver;

public interface Page {

    String getTitleOfPage(WebDriver driver);
    boolean verifyBasePageTitle(String expectedTitle, WebDriver driver);
}
