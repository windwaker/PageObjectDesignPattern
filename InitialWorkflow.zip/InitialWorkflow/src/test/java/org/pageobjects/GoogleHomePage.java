package org.pageobjects;

public class GoogleHomePage extends BasePage{


}


