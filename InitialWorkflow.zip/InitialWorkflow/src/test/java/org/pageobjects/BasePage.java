package org.pageobjects;

import org.openqa.selenium.WebDriver;

public abstract class BasePage implements Page{

    @Override
    public String getTitleOfPage(WebDriver driver) {
        return driver.getTitle();
    }

    @Override
    public boolean verifyBasePageTitle(String expectedTitle, WebDriver driver) {
        return getTitleOfPage(driver).equalsIgnoreCase(expectedTitle);
    }

}
