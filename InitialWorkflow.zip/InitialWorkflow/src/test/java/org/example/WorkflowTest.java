package org.example;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WorkflowTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @Before
    public void setup(){
        String baseDir = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver", baseDir + "/drivers/chromedriver");
        driver = new ChromeDriver();
    }

    @Test
    public void test1() throws InterruptedException {

        driver.navigate().to("https://www.google.com");

        wait = new WebDriverWait (driver, 10);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                By.cssSelector("#cnsw > iframe")));

        WebElement we = driver.findElement(By.cssSelector("#introAgreeButton"));
        we.click();
        driver.switchTo().defaultContent();

        By name = By.name("q");

        driver.findElement(name).sendKeys("selenium webdriver");

        Thread.sleep(2000);

        By third = By.cssSelector("li:nth-child(3)");

        driver.findElement(third).click();

        Assert.assertTrue(true);
    }

    @After
    public void tearDown(){
        driver.close();
        driver.quit();
    }
}
